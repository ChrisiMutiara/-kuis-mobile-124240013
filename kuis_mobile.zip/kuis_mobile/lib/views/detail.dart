import 'package:flutter/material.dart';
import 'package:kuis_mobile/models/data.dart';      


class DetailPage extends StatelessWidget {
  final Product product;                                

  const DetailPage({super.key, required this.product});   

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(product.productName)),     

      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.network(                         
            product.imageUrl,                           
            width: double.infinity,
            height: 220,
            fit: BoxFit.cover,
          ),
          SizedBox(height: 16),

          Text(
            product.productName,                            
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 4),

          Text(
            product.type,
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),                    
          SizedBox(height: 8),

          Text(
            product.price,                           
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green),
          ),
          SizedBox(height: 16),




          Text(
            "Deskripsi",                        
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),

          Text(product.details),                 
        ],
      ),
    );
  }
}