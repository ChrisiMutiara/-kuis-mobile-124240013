import 'package:flutter/material.dart';
import 'package:kuis_mobile/models/data.dart';       
import 'package:kuis_mobile/views/detail.dart';      

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController searchController = TextEditingController();

  String keyword = "";                    
  String kategoriTerpilih = "Semua";      

  @override
  Widget build(BuildContext context) {
    List<Product> hasilFilter = catalog.where((product) {        
      bool cocokNama = product.productName.toLowerCase().contains(keyword.toLowerCase());   
      bool cocokKategori = kategoriTerpilih == "Semua" || product.type == kategoriTerpilih;  
      return cocokNama && cocokKategori;
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12.0),
          child: TextField(
            controller: searchController,
            onChanged: (value) {
              setState(() {
                keyword = value;          
              });
            },
            decoration: InputDecoration(
              hintText: "Cari pakaian...",     
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(20)),
              ),
            ),
          ),
        ),

        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12.0),
          child: Row(
            children: [
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    kategoriTerpilih = "Semua";    
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: kategoriTerpilih == "Semua" ? const Color.fromARGB(255, 187, 202, 248) : Colors.grey[300],   // ganti warna aktif/nonaktif
                ),
                child: Text("Semua"),          
              ),
              SizedBox(width: 8),

              ElevatedButton(
                onPressed: () {
                  setState(() {
                    kategoriTerpilih = "T-Shirt";   
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: kategoriTerpilih == "T-Shirt" ? const Color.fromARGB(255, 187, 193, 248) : Colors.grey[300],
                ),
                child: Text("T-Shirt"),             
              ),
              SizedBox(width: 8),

              ElevatedButton(
                onPressed: () {
                  setState(() {
                    kategoriTerpilih = "Jacket";   
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: kategoriTerpilih == "Jacket" ? Colors.pink[100] : Colors.grey[300],
                ),
                child: Text("Jacket"),         
              ),
              SizedBox(width: 8),

              ElevatedButton(
                onPressed: () {
                  setState(() {
                    kategoriTerpilih = "Pants";   
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: kategoriTerpilih == "Pants" ? Colors.pink[100] : Colors.grey[300],
                ),
                child: Text("Pants"),      
              ),

              ElevatedButton(
                onPressed: () {
                  setState(() {
                    kategoriTerpilih = "Bag";   
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: kategoriTerpilih == "Bag" ? Colors.pink[100] : Colors.grey[300],
                ),
                child: Text("Bag"),         
              ),

              ElevatedButton(
                onPressed: () {
                  setState(() {
                    kategoriTerpilih = "Accessories";   
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: kategoriTerpilih == "Accessories" ? Colors.pink[100] : Colors.grey[300],
                ),
                child: Text("Accessories"),        
              ),
            ],
          ),
        ),

        SizedBox(height: 8),
      
        Expanded(
          child: hasilFilter.isEmpty
              ? Center(child: Text("Pakaian tidak ditemukan"))    
              : ListView.builder(
                  itemCount: hasilFilter.length,
                  itemBuilder: (context, index) {
                    return ListTile(
          
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DetailPage(product: hasilFilter[index]),   
                          ),
                        );
                      },

                      title: Text(hasilFilter[index].productName),       

                      subtitle: Text("${hasilFilter[index].type} - ${hasilFilter[index].price}"),   

                      leading: Image.network(                      
                        hasilFilter[index].imageUrl,                   
                        width: 50,
                        height: 50,
                      ),

                      trailing: Icon(Icons.arrow_forward_ios),
                    );
                  },
                ),
        ),
      ],
    );
  }
}