import 'package:flutter/material.dart';
import 'package:kuis_mobile/root.dart';              
import 'package:kuis_mobile/models/data.dart';       

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController usernameController = TextEditingController();  
  final TextEditingController passwordController = TextEditingController();

  bool isLoggedIn = false;                          
  void login() {
    String username = usernameController.text;      
    String password = passwordController.text;

    if (account.username.isEmpty || account.password.isEmpty) {     
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.orange,
          content: Text("Username dan password tidak boleh kosong"),  
        ),
      );
      return;
    }

    if (username == account.username && password == account.password) {   
      setState(() {
        isLoggedIn = true;
      });

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => Root(username: username)),   
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.green,
          content: Text("Login Berhasil"),          
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: Text("Login Gagal. Username atau Password Salah"), 
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,         
        foregroundColor: Colors.white60,
        title: Text("kuis"),                  
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(25.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                "assets/images/uniqlo.png",
                width: 150,
                height: 150,
              ),

              SizedBox(height: 8),
              Text("Selamat Datang di Uniqlo Selamat Berbelanja"),
              SizedBox(height: 40),
              

              TextField(
                controller: usernameController,
                decoration: InputDecoration(
                  hintText: "username",            
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                ),
              ),
              SizedBox(height: 20),

              TextField(
                controller: passwordController,
                obscureText: true,                  
                decoration: InputDecoration(
                  hintText: "password",          
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                ),
              ),
              SizedBox(height: 20),

              SizedBox(
                height: 40,
                width: 180,
                child: ElevatedButton(
                  onPressed: login,
                  child: Text("Login"),          
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 129, 142, 233), 
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}